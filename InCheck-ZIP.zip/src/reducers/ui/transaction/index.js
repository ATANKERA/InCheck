import { combineReducers } from 'redux';
import filter from './filter';

export default combineReducers({ filter });
