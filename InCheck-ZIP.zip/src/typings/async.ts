export type AsyncOperationStateT = 'REQUEST' | 'SUCCESS' | 'FAILURE';
