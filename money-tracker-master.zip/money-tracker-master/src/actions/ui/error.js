import { createActions } from 'redux-actions';

export const { showError } = createActions('SHOW_ERROR');
