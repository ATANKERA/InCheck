import { createAction } from 'redux-actions';

export const windowResize = createAction('WINDOW_RESIZE');
